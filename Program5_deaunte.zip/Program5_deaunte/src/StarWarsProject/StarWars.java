package StarWarsProject;

/*
 * 	Name: Deaunte Gay
 * 	Course: CIS 4020 01N
 * 	Semester: Fall 2016
 * 	Assignment: Program 5
 * 	Date started: 9/30/16
 * 	Date completed: 10/02/16
 * 
 * 	Description: Program that simulates a battle between the Rebels and Empire. A Star Destroyer comes in the last 
 * 	moments of the battle and destroys anything remaining, even its own faction.
 */

import java.util.Random;

// Class: StarShip
// Description: Super-class for all star ships, sets the pilot, shields, weapon, and dead status of a ship. 
class StarShip {
	protected int shields;		// Stores the remaining charge on the shield
	protected int weapon;		// Stores the amount of damage the weapon causes
	protected boolean dead;		// Stores whether the ship is destroyed or not
	protected String pilot;		// Stores the name of who is piloting the ship
	
	// Function: StarShip
	// Description: Constructor for the superclass, sets the pilot's name.
	// Input:	faction - integer value to determine which ship to have a pilot for
	// Output:	pilot - property value changed
	public StarShip(int faction) {
		// If statements will see which ship a pilot should be assigned to.
		if (faction == 0) {		// X-Wings
			Random randomSelection = new Random();															// Randomly selects a value from the array
			String[] names = {"Luke Skywalker", "Han Solo", "Chewbacca", "Lando Calrissian", "Nien Nunb"};	// Names to choose from for pilots
			
			pilot = names[randomSelection.nextInt(5)];
		} else if (faction == 3) {	// Star Destroyers
			Random randomSelection = new Random();																			// Randomly selects a value from the array
			String[] names = {"John", "Brian", "Alex", "Harold", "George", "Thomas", "Gregory", "Jack", "Ben", "Steve"};	// Names to choose from for pilots
			
			pilot = names[randomSelection.nextInt(10)];
		} else { // Tie Fighters
			Random randomSelection = new Random();						// Generates random numbers to assign a stormtrooper
			String name = "FN-";										// Stores the name of the stormtrooper
			
			// A random number is generated 5 times and appended to the exisiting string. This creates 
			// the stormtrooper assignment
			for(int i = 0; i < 6; i++) {
				name += String.valueOf(randomSelection.nextInt(10));
			} // end loop
			
			pilot = name;
		} // end if statement
	} // end function: StarShip
	
	// Function: isDead
	// Description: Returns the value of whether the ship has been destroyed or not.
	// Input: none
	// Output: Boolean value of dead property
	public boolean isDead() {
		return dead;
	} // end function: isDead
	
	// Function: hit
	// Description: Deducts damage from the ship's shield. If shields are less than 0, the ship is destroyed.
	// Input: damage - integer value of damage on shield
	// Output: 	dead - property value may change if shields are less than 0
	//			shields - property value deducted
	public void hit(int damage) {
		shields = shields - damage;
		
		if (shields < 0) {
			System.out.println("Boom!!!");
			dead = true;
		}
	} // end function: hit
	
	// Function: getWeapon
	// Description: Returns the damage amount of the weapon on the ship.
	// Input: none
	// Output: weapon - integer value telling how much damage the weapon does
	public int getWeapon() {
		return weapon;
	} // end function
	
	// Function: getPilot
	// Description: Returns the pilot of the ship
	// Input: none
	// Output: pilot - String value of pilot's name
	public String getPilot() {
		return pilot;
	} // end function
} // end class: StarShip


// Class: XWing
// Description: A subclass of StarShip; sets the shield value and weapon values of the ship.
class XWing extends StarShip {
	
   // Function: XWing
   // Description: Constructor for the class; sets shield and weapon values. Calls the super constructor to assign a pilot.
   // Input: none
   // Output: all fields are edited
   public XWing()
   {
	  super(0);
      shields = 1000;
      weapon  = 10;
   } // end function: XWing
} // end class: XWing

// Class: TieFighter
// Description: A subclass of StarShip; sets the shield value and weapon values of the ship.
class TieFighter extends StarShip {
  
   // Function: TieFighter
   // Description: Constructor for the class; sets the shield and weapon values. Calls the super constructor to assign a pilot.
   public TieFighter()
   {
	  super(1);
      shields = 500;
      weapon  = 20;
   } // end function: TieFighter
} // end class: TieFighter

// Class: StarDestroyer
// Description: Subclass of StarShip; contains two additional administrators on ship and functions to pull those administrators.
class StarDestroyer extends StarShip {
	
	private String copilot;			// Stores the name of the copilot
	private String commander;		// Stores the name of the commander
	
	// Function: StarDestroyer
	// Description: Constructor for the class; sets values of shields and weapon. Also assigns a copilot and commander.
	// Input: none
	// Output: all class properties are changed
	public StarDestroyer() {
		super(3);
		shields = 10000;
		weapon = 500;
		
		
		String[] names = {"John", "Brian", "Alex", "Harold", "George", "Thomas", "Gregory", "Jack", "Ben", "Steve"};	// Array of names to choose from
		Random randomNumber = new Random();																				// Randomly selects a name from the array and stormtrooper commander
		String temp = "FN-";		// Holds the name for the commander (a stormtrooper)
		
		// Randomly generates a number between 0-9 and assigns it to the stormtrooper name. Creates
		// the stormtrooper commander.
		for(int i = 0; i < 6; i++) {
			temp += randomNumber.nextInt(10);
		} // end for loop
		
		// Assigns names to properties
		copilot = names[randomNumber.nextInt(10)];
		commander = temp;
	} // end function: StarDestroyer
	
	
	// Function: getCoPilot
	// Description: Returns the copilot of the star destroyer.
	// Input: none
	// Output: copilot - String value of copilot name
	public String getCoPilot() {
		return copilot;
	} // end function: getCoPilot
	
	// Function: getCommander
	// Description: Returns the commander of the star destroyer.
	// Input: none
	// Output: commander - String value of commander name
	public String getCommander() {
		return commander;
	} // end function: getCommander
} // end class: StarDestroyer

// Class: StarWars
// Description: Contains functions to duel and battle between X-Wings, Tie Fighters, and Star Destroyers
class StarWars {
	
	// Function: duel
	// Description: Duels a XWing and TieFighter against each other
	// Input:	x - XWing object
	//			t - TieFighter object
	// Output: 	Both object's fields can be changed and one object will be "destroyed".
   private void duel(XWing x, TieFighter t)
   {
	   // Loop will simulate a battle between the two ships; when a ship is destroyed, it is sent to the program console.
      for (;;)
      {
         x.hit(t.getWeapon());       
         if (x.isDead())
         {
            System.out.println("X-Wing is dead");
            break;
         }
         t.hit(x.getWeapon());
         if (t.isDead())
         {
            System.out.println("Tie Fighter is dead");
            break;
         }
      } // end for loop
   } // end function: duel
   
   // Function: duel
   // Description: Duels an XWing fighter against a StarDestroyer
   // Input:	x - XWing object
   // 			s - StarDestroyer object
   // Output: Both object's properties may be changed. One object will be "destroyed".
   private void duel(XWing x, StarDestroyer s) {
	   // Simulates the battle between an XWing and Star Destroyer. Writes to console whenever one is destroyed
	   // (most likely, the X-Wing).
	   for (;;) {
		   x.hit(s.getWeapon());
		   if (x.isDead()) {
			   System.out.println("X-Wing is dead");
			   break;
		   }
		   
		   s.hit(x.getWeapon());
		   if (s.isDead()) {
			   System.out.println("Star Destroyer is dead");
			   break;
		   }
	   } // end for loop
   } // end function: duel
   
   // Function: duel
   // Description: Duels a TieFighter against a StarDestroyer
   // Input:	t - TieFighter object
   //			s - StarDestroyer object
   // Output: Both object's properties will be changed; one object will be "destroyed".
   private void duel(TieFighter t, StarDestroyer s) {
	   // Loop that simulates a fight between a TieFighter and StarDestroyer. Writes to console when a ship is destroyed.
	   // (Most likely a Tie Fighter).
	   for (;;) {
		   t.hit(s.getWeapon());
		   if (t.isDead()) {
			   System.out.println("TieFighter is dead");
			   break;
		   }
		   
		   s.hit(t.getWeapon());
		   if (s.isDead()) {
			   System.out.println("Star Destroyer is dead");
			   break;
		   }
	   } // end for loop
   } // end function: duel

   // Function: battle
   // Input:	good - array of XWing objects (XWing fleet)
   //			evil - array of TieFighter objects (TieFighter fleet)
   //			mothership - StarDestroyer object that will destroy everything at the end
   // Output: 	console - Fights against each object, as well as a battle summary
   private void battle(XWing[] good, TieFighter[] evil, StarDestroyer mothership)
   {
      int g = 0;			// Stores current point in good array
      int e = 0;			// Stores current point in evil array
      int goodDeaths = 0;	// Stores amount of dead XWings
      int evilDeaths = 0;	// Stores amount of dead TieFighters
      
      // While there are remaining ships, each ship in each array faces against each other. 
      // Whichever ship is destroyed, the death count for its respected faction is increased.
      while (g < good.length && e < evil.length)
      {
         System.out.println("battling X-Wing #" + g + " piloted by " + good[g].getPilot() +
                            " versus Tie Fighter #" + e + " piloted by " + evil[e].getPilot());
         duel(good[g],evil[e]);
         
         if (good[g].isDead())
         {
            g++;
            goodDeaths++;
         }
         
         if (evil[e].isDead())
         {
            e++;
            evilDeaths++;
         }
      } // end while loop
      
      int finalGood = good.length - goodDeaths;		// Stores value of surviving XWings
      int finalEvil = evil.length - evilDeaths;		// Stores value of surviving TieFighters

      // Prints a battle report showing which faction survived the battle.
      System.out.println();
      System.out.println("Battle Report:\t\tX-Wings\t\tTie Fighters");
      System.out.println("------------------------------------------------------");
      System.out.println();
      System.out.println("Initial ships:\t\t" + good.length + "\t\t" + evil.length);
      System.out.println();
      System.out.println("Killed ships:\t\t"  + goodDeaths  + "\t\t" + evilDeaths);
      System.out.println();
      System.out.println("Final ships:\t\t"   + finalGood   + "\t\t" + finalEvil);
      System.out.println();
      
      // If statements checks to see which faction survived. A Star Destroyer comes and destroys the remaining
      // surviving faction ships, even if it is a Tie Fighter. Prints to console.
      if (finalGood > finalEvil)
      {
    	 System.out.println("Battling X-Wing #" + g + " piloted by " + good[g].getPilot() +
    			 			" versus a Star Destroyer pioted by " + mothership.getPilot() + " and " + mothership.getCoPilot() +
    	 					" commanded by " + mothership.getCommander());
    	 duel(good[g], mothership);
         System.out.println("The rebel alliance was victorious, but Darth Vader had other plans.");
      }
      else
      {
    	 System.out.println("Battling TieFighter #" + e + " piloted by " + evil[e].getPilot() +
		 			" versus a Star Destroyer pioted by " + mothership.getPilot() + " and " + mothership.getCoPilot() +
					" commanded by " + mothership.getCommander());
    	 duel(evil[e], mothership);
         System.out.println("The dark side has conquered, but Darth Vader had other plans.");
      } // end if statement
      
      System.out.println();
   } // end function: battle
   
   // Function: doStuff
   // Description: Initializes the arrays for XWings and TieFighters; initalizes a Star Destroyer
   // Input: none
   // Output:	goodies - XWing fleet (array of XWing objects)
   //			baddies - Tie Fighter fleet (array of TieFighter objects)
   // 			mothership - StarDestroyer object
   public void doStuff()
   {
      // defines the goodies array
      XWing[] goodies = new XWing[3];

      // Initializes the elements of the goodies array
      for (int i=0; i<goodies.length; i++)
      {
         goodies[i] = new XWing();
      }
    
      // defines the baddies array
      TieFighter[] baddies = new TieFighter[3];

      // Initializes the elements of the baddies array
      for (int i=0; i<baddies.length; i++)
      {
         baddies[i] = new TieFighter();
      }
      
      // Initializes a Star Destroyer
      StarDestroyer mothership = new StarDestroyer();
    
      // Invokes a battle between both factions and sends a Star Destroyer to clean up after.
      battle(goodies,baddies, mothership);
      
   }  // end function: doStuff

   // Function: main
   // Description: Tells the battle to begin; creates a StarWars object than calls to start battle.
   // Input: none
   // Output: console - battle results printed to console
   public static void main(String[] args)
   {
      StarWars me = new StarWars();
      me.doStuff();
   } // end function: main
}
