/*
 * Name: Deaunte Gay
 * Course: CIS 4020 01N
 * Semester: Fall 2016
 * Assignment: Program 10
 * Date Started: 11/12/16
 * Date Finished: 11/12/16
 * 
 * Description: Sorts the identification number of stormtroopers.
 */

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

// Class: StormtrooperSort
// Description: Displays and receives input of the status of sorting stormtroopers.
public class StormTrooperSort {
	private static int[] resultArray;	// stores the array 

	// Function: main
	// Description: Calls to receive input and perform the two sorts.
	// Input: User input from keyboard.
	// Output: Status displayed on the console.
	public static void main(String[] args) {
		recieveInput();			// Calls method to receive user input
		performMySort();		// Calls method to perform my sort
		performBuiltInSort();	// Calls method to perform Java sort
	} // end function: main
	
	// Function: shuffle
	// Description: Shuffles the array in order to resort the array using the two methods.
	// Input: array - the array to be rearranged
	// Output: array - array is rearranged in a random order
	private static void shuffle(int[] array) {
		Random numbers = new Random();	// Used to randomly select an array point to switch out with
		
		// For loop that will iterate through each item. It then selects a random array point and swaps values
		// with that point. 
		for(int j = 0; j < array.length - 1; j++) {
			int k = numbers.nextInt(array.length - 1);	// Stores point that was randomly selected
			
			// Stores old value from array
			int oldValue = array[j];
			
			// Swaps values from one spot to the other.
			array[j] = array[k];
			array[k] = oldValue;
		} // end for loop
	} // end function: shuffle
	
	// Function: recieveInput
	// Description: Receives and validates the user's input. Stores the result and creates an array 
	// 		with the size requested.
	// Input: keyboard
	// Output: array is initialized with the input requested
	private static void recieveInput() {
		Scanner keyboard = new Scanner(System.in);		// Receives user input
		
		// Prompts user to enter a positive integer. Stores the result into a variable.
		System.out.println("Enter a positive number: ");
		int result = keyboard.nextInt();
		
		// resultArray is initialized to the size requested
		resultArray = new int[result];
		
		// For loop that sets the value of each array spot to its previous value plus 1, starting at 1.
		for(int i = 0; i < result; i++) {
			resultArray[i] = i + 1;
		} // end for loop
	} // end function: recieveInput
	
	// Function: performMySort
	// Description: Performs my merge sort and reorders the array.
	// Input: none
	// Output: console - prompts showing sort beginning and ending
	private static void performMySort() {
		shuffle(resultArray);		// Shuffles array
		System.out.println("Start My Sort");
		
		// Creates MySort object. Then, sorts the array using a merge sort.
		MySort ms = new MySort();
		ms.sort(resultArray);

		System.out.println("End My Sort");
	} // end function: performMySort
	
	// Function: performBuiltInSort
	// Description: Performs the built in Java sort and reorders the array.
	// Input: none
	// Output: console - prompts showing sort beginning and ending
	private static void performBuiltInSort() {
		shuffle(resultArray);		// Shuffles the array
		System.out.println("Start Built-In Sort");
		
		// Calls the Java sort for arrays and sorts the array.
		Arrays.sort(resultArray);
		System.out.println("End Built-In Sort");
	} // end function: performBuiltInSort
} // end class: StormtrooperSort
