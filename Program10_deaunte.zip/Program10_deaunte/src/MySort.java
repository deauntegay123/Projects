
	/*
	 * Name: Deaunte Gay
	 * Course: CIS 4020 01N
	 * Semester: Fall 2016
	 * Assignment: Program 10
	 * Date Started: 11/12/16
	 * Date Finished: 11/12/16
	 * 
	 * Description: Sorts the identification number of stormtroopers.
	 */

	import java.util.Arrays;

	// Class: MySort
	// Description: Performs the sorting operations for merge sort.
	public class MySort {
		int[] array;			// Stores the actual array.
		int[] tempMergeArray;	// Temp array that stores sub-arrays
		int length;				// Stores the length of the array
		
		// Function: sort
		// Description: Initializes the values for array, tempMergeArray and length; calls the mergeSort method.
		// Input: inputArray - an array of integer values
		// Output: none
		public void sort(int inputArray[]) {
			this.array = inputArray;
			this.length = inputArray.length;
			this.tempMergeArray = new int[length];
			mergeSort(0, length - 1);
		} // end function: sort
		
		// Function: mergeSort
		// Description: Recursive method that splits an array up to smaller pieces, then reorders and merges the pieces together.
		// Input: 	int left - the leftmost side of the array the method should look at
		//			int right - the rightmost side of the array the method should look at
		// Output: The array is sorted in proper order.
		private void mergeSort(int left, int right) {
			// When the left side is less than the right side in the array point, 
			// it will end the recursive call. Otherwise, it will split and reorder until this holds true.
			if (left < right) {
				int mid = (left + right)/2;			// finds the midpoint to split the array into
				mergeSort(left, mid);				// Calls itself to split the left side
				mergeSort(mid + 1, right);			// Calls itself to split the right side
				combineParts(left, mid, right);		// Combines the array together 
			} // end if statement
		} // end function: mergeSort
		
		// Function: combineParts
		// Description: Combines two arrays together and orders them at the same time.
		// Input:	int left - the leftmost portion of the array for the method to look at
		// 			int mid - the midpoint of the array
		// 			int right - the rightmost portion of the array for the method to look at
		// Output: 	Array is merged together and reordered properly
		private void combineParts(int left, int mid, int right) {
			// Stores the split array into the temp array.
			for (int i = left; i <= right; i++) {
				tempMergeArray[i] = array[i];
			}
			
			// Initial points for while loops
			int i = left;
			int j = mid + 1;
			int k = left;
			
			// Checks for the lesser value and stores it into the array in the proper order. 
			// Increments based on which side was picked out. 
			// Increments the point in the final array as well.
			while(i <= mid && j <= right) {
				if(tempMergeArray[i] <= tempMergeArray[j]) {
					array[k] = tempMergeArray[i];
					i++;
				} else {
					array[k] = tempMergeArray[j];
					j++;
				}
				
				k++;
			} // end while loop
			
			// If there are extra values that do not compare to the other array, they are added into the
			// final array as they will already be in order.
			while(i <= mid) {
				array[k] = tempMergeArray[i];
				k++;
				i++;
			} // end while loop
		} // end function: combineParts
	} // end class: MySort



