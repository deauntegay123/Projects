package Program11;

/***************************************
 * Name: Deaunte Gay
 * Course: CIS 4020	
 * Semester: Spring 2016 
 * Assignment: Program 11 - TieFighterStack
 * Date started: 11/18/2016
 * Date finished: 11/19/2016
 *
 * Description:  		- read input from tifighters.txt file
 * 						- if first item in line is 1, place given fighter id into appropriate stack.
 * 							This will be stackA if not full, stackB, if stackA is full.
 * 							If both stacks are full, fighter will be pushed into main hangar
 * 						- if first item in line is 2, launch fighter from appropriate stack
 * 							This will be stack A if it isn't empty, and will be stack B
 * 							if A is empty. If both are empty, reroute command to hangar bay
 * 						- if first item in line is 3, launch ALL fighters from both stacks.
 * 							if both stacks are empty, reroute command to main hangar bay
 *  
 * IMPORTANT			- I left a few things in (either commented out or otherwise) that I used for testing.
 * 							These were left in solely to make it easier for you to read what is happening, rather than
 * 							just having a big list of things and having to read through an annoying 
 * 							wall of text. I also formatted the output file to include statements showing what was 
 * 							read in for each line. 
 * 							
 ****************************************/

import java.io.*;
import java.util.Stack;

public class TieFighterStack {

	//create two stacks
	static Stack<Integer> stackA = new Stack<Integer>();
	static Stack<Integer> stackB = new Stack<Integer>();
	
	public static void main(String[] args) {
		setOutputToFile();	//method to send System.out to hangerlog.txt file
		//read file into stream, try-with-resources
		try (BufferedReader br = new BufferedReader(new FileReader("tiefighters.txt"))) {
			// loop through file to get input while the next line is not null
			// if code == 1, parse line starting at fighter id to integer for putting into corresponding stack
			String line; int x = 0; int lineNum = 0;
			while ((line = br.readLine()) != null) {
				lineNum++; 	//increment line number counter. This makes keeping track of input codes easier
				if (line.substring(0,1).equals("1")) {
					x = Integer.parseInt(line.substring(2));
					System.out.println("Input code at line " + lineNum + " is " + line.substring(0,1) + " -- \"Receive Tie-Fighter\"");	//TEST
					receiveTieFighter(x);	
				}
				else if (line.substring(0,1).equals("2")) {
					System.out.println("Input code at line " + lineNum + " is " + line.substring(0,1) + " -- \"Launch Single Tie-Fighter\"");	//TEST
					//System.out.println("Popping one");
					launchSingleFighter();
				}
				else if (line.substring(0,1).equals("3")) {
					System.out.println("Input code at line " + lineNum + " is " + line.substring(0,1) + " -- \"Launch All Tie-Fighters\"");	//TEST						//TEST
					//System.out.println("Popping all.");
					launchAllFighters();
				} //end if/else statement 	
				/*the output below prints sizes of stacks A and B, respectively, to the hangerlog.txt file underneath the current process taking place. 
				  Used by me during testing. Left as comment in case you wanted to check the stack processes without having to manually count them */
				//System.out.print(">>>>>>>>>>>>>>>>>>>  " + stackA.size() + " & " + stackB.size());
				System.out.println();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}		
		//output both stacks after processing input codes, then exit
		System.out.println("---------------------------------------------------");
		printStackA();
		printStackB();
		System.exit(0);
	} // end main()
	
	//place tie fighters into appropriate stacks
	private static void receiveTieFighter (int x) {
		int fighterID = x;
		//if stackA is not full, push fighter into stack A
		if (stackA.size() < 10) {
			stackA.push(fighterID);
			System.out.println("	Tie Fighter " + fighterID + " has docked in stack A.");
		//if stack A is full and B is not, push fighter into stack B
		} else if (stackB.size() < 10) {
			stackB.push(fighterID);
			System.out.println("	Tie Fighter " + fighterID + " has docked in stack B.");
		//if both stacks are full, send to main hangar	
		} else {
			System.out.println("	Tie Fighter " + fighterID + " has been rerouted to main hanger bay.");
		} //end if/else statement
	}// end of recieveTieFighter(int) method
	
	//launch tie fighter from appropriate stack
	private static void launchSingleFighter() {
		//if stack A is not empty, launch fighter from stack A
		if (stackA.isEmpty() == false) {
			System.out.println("	Tie Fighter " + stackA.peek() + " has launched from stack A.");
			stackA.pop();
		//if stack A is empty, but B isn't, launch fighter from stack B	
		} else if (stackB.isEmpty() == false) {
			System.out.println("	Tie Fighter " + stackB.peek() + " has launched from stack B.");
			stackB.pop();
		//if both stacks are empty, rerout command to hangar bay	
		} else if (stackA.isEmpty() == true && stackB.isEmpty() == true){
			System.out.println("	Bay is empty, command rerouted to main hanger bay.");
		} //end if/else statement
	} //end launchSingleFighter() method
	
	//launch all fighters, emptying both stacks
	private static void launchAllFighters() {
		//while stack A is not empty, launch all fighters from stack A
		while (stackA.isEmpty() == false) {
			System.out.println("	Tie Fighter " + stackA.peek() + " has launched from stack A.");
			stackA.pop();
		} //end loop
		//while stack B is not empty, launch all fighters from stack B
		while (stackB.isEmpty() == false) {
			System.out.println("	Tie Fighter " + stackB.peek() + " has launched from stack B.");
			stackB.pop();
		} //end loop
	} //end launchAllFighters() method

	//send System.out to hangarlog.txt file
	private static void setOutputToFile() {
		//creates hangarlog.txt file if it doesn't exist. 
		//Throws error if file can't be created for some reason
		try {
		    System.setOut(new PrintStream(new File("hangarlog.txt")));
		} catch (Exception e) {
		     e.printStackTrace();
		}
	} //end setOutputToFile() method
	
	//prints contents of stackA from top to bottom 
	private static void printStackA () {
		System.out.println();
		System.out.print("Stack A contains Tie-Fighters: ");
		//print contents of stack A, before removing the items
		while (stackA.isEmpty() == false) {
			System.out.print(stackA.peek()); 
			if (stackA.size() > 1) 
				System.out.print(", ");
			stackA.pop();
		} //end loop
	} //end of printStackA() method
	
	//prints contents of stackB from top to bottom
	private static void printStackB () {
		System.out.println();
		System.out.print("Stack B contains Tie-Fighters: ");
		//print contents of stack B, before removing the items
		while (stackB.isEmpty() == false) {
			System.out.print(stackB.peek());
			if (stackB.size() > 1) 
				System.out.print(", ");
			stackB.pop();
		} //end loop
	} //end of printStackB() method
}

