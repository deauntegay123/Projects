
public class Clone {
	private int cloneID;
	private double materialCost;
	private double foodCost;
	
	public Clone() {
		this.cloneID = 0;
		this.materialCost = 0;
		this.foodCost = 0;
	}
	
	public void setCloneID(int cloneID) {
		this.cloneID = cloneID;
	}
	
	public void setMaterialCost(double materialCost) {
		this.materialCost = materialCost;
	}
	
	public void setFoodCost(double foodCost) {
		this.foodCost = foodCost;
	}
	
	public int getCloneID() {
		return cloneID;
	}
	
	public double getMaterialCost() {
		return materialCost;
	}
	
	public double getFoodCost() {
		return foodCost;
	}
}
