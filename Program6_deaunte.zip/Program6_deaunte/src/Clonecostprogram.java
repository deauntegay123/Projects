import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Currency;
import java.util.Scanner;

public class Clonecostprogram {

	public static void main(String[] args) {
		ArrayList<Clone> clones = new ArrayList<Clone>();
		int correctRecords = 0;
		int recordsWithErrors = 0;
		double materialAverage = 0;
		double materialTotal = 0;
		double foodAverage = 0;
		double foodTotal = 0;
		
		try {
			File myFile = new File("costs.txt");
			Scanner inputFile = new Scanner(myFile);
			
			while (inputFile.hasNext()) {
				try {
					readLines(inputFile, clones);
					correctRecords++;
				} catch (NumberFormatException e) {
					System.out.println("Nonnumeric data encountered in the file: " + e.getMessage());
					System.out.println("The invalid record will be skipped.");
					recordsWithErrors++;
				}
			};
			
			materialTotal = getTotals(clones, 0);
			foodTotal = getTotals(clones, 1);
			materialAverage = materialTotal / clones.size();
			foodAverage = foodTotal / clones.size();
			
			createBinaryFile(clones);
			createCleanRecord(clones);
			printConsole(correctRecords, recordsWithErrors, materialTotal, foodTotal, materialAverage, foodAverage);
		} catch (FileNotFoundException e) {
			System.out.println("File not found: costs.txt");
			System.out.println(e.getMessage());
		} 
	}
	
	public static void readLines(Scanner inputFile, ArrayList<Clone> clones) {
		String line = inputFile.nextLine();
		String[] cloneLine = line.split(" ");
		Clone cloneItem = new Clone();
		cloneItem.setCloneID(Integer.valueOf(cloneLine[0]));
		cloneItem.setMaterialCost(Double.valueOf(cloneLine[1]));
		cloneItem.setFoodCost(Double.valueOf(cloneLine[2]));
		
		clones.add(cloneItem);
	}
	
	public static void printConsole(int correctRecords, int recordsWithErrors, double materialTotal, double foodTotal, double materialAverage, double foodAverage) {
		NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance();
		
		System.out.println("Correct records: " + correctRecords);
		System.out.println("Error records: " + recordsWithErrors);
		System.out.println("Total material: " + currencyFormatter.format(materialTotal));
		System.out.println("Average material: " + currencyFormatter.format(materialAverage));
		System.out.println("Total food: " + currencyFormatter.format(foodTotal));
		System.out.println("Average food: " + currencyFormatter.format(foodAverage));
	}
	
	public static void createCleanRecord(ArrayList<Clone> clones) {
		try {
			FileWriter outputFile = new FileWriter("cleaned.txt", true);
			PrintWriter writeFile = new PrintWriter(outputFile);
			
			for (Clone item : clones) {
				writeFile.println(item.getCloneID() + " " + item.getMaterialCost() + " " + item.getFoodCost());
			}
			
			writeFile.close();
		} catch (IOException e) {
			System.out.println("Unable to create file: " + e.getMessage());
		}
	}
	
	public static void createBinaryFile(ArrayList<Clone> clones) {
		try {
			FileOutputStream fstream = new FileOutputStream("cleaned.bin");
			DataOutputStream outputFile = new DataOutputStream(fstream);
			
			for (Clone item : clones) {
				outputFile.writeInt(item.getCloneID());
				outputFile.writeDouble(item.getMaterialCost());
				outputFile.writeDouble(item.getFoodCost());
			}
			
			outputFile.close();
		} catch (FileNotFoundException e) {
			System.out.println("Cannot find file: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("Cannot write data to file: " + e.getMessage());
		}
	}
	
	public static double getTotals(ArrayList<Clone> clones, int selection) {
		double total = 0;
		
		if (selection == 0) {
			for (Clone item : clones) {
				total += item.getMaterialCost();
			}
		} else {
			for (Clone item: clones) {
				total += item.getFoodCost();
			}
		}
		
		return total;
	}
}
